import sys
import tutor
import pet
import agenda

def exibir_painel_principal(sessao_ativa):
    if not sessao_ativa or not sessao_ativa.get("id_usuario"):
        print("\n[ERRO] Acesso negado. Nenhuma sessão ativa validada.")
        return

    while True:
        print("\n" + "*"*45)
        print("   SISTEMA DE GESTÃO - PETSHOP   ")
        print("="*45)
        print(f" Usuário Logado: {sessao_ativa.get('nome')}")
        print("-" * 45)
        print("1. Tutores ")
        print("2. Pets ")
        print("3. Agenda ")
        print("4. Sair do Sistema ")
        print("="*45)
        opcao = input("Selecione uma opção de navegação: ").strip()

        if opcao == '1':
            print("\n>> Redirecionando para o Módulo de tutores...")
            tutor.iniciar_modulo()

        elif opcao == '2':
            print("\n>> Redirecionando para o Módulo de Pets...")
            pet.iniciar_modulo()

        elif opcao == '3':
            print("\n>> Redirecionando para o Módulo de Agendamentos...")
            agenda.iniciar_modulo()

        elif opcao == '4':
            print(f"\nEncerrando a sessão de {sessao_ativa.get('nome')}...")
            sessao_ativa.clear()
            print("Logout realizado com sucesso. O sistema foi encerrado.")
            break

        else:
            print("\n[AVISO] Opção inválida. Escolha um número entre 1 e 4.")

if __name__ == "__main__":
    exibir_painel_principal()

import mysql.connector
from datetime import datetime
import sys

def conectar_banco():
    try:
        return mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="saep_db"
        )
    except mysql.connector.Error as err:
        print(f"Erro ao conectar ao banco de dados: {err}")
        sys.exit(1)

def listar_tutores_disponiveis(cursor):
    cursor.execute("SELECT id_tutor, nome FROM tutor")
    tutores = cursor.fetchall()

    if not tutores:
        print("Nenhum tutor tutor encontrado. Cadastre um tutor primeiro.")
        return False

    print("\n--- tutores TUTORES DISPONÍVEIS ---")
    for c in tutores:
        print(f"ID: {c['id_tutor']} | Nome: {c['nome']}")
    print("-" * 38)
    return True

def cadastrar_pet():
    conexao = conectar_banco()
    cursor = conexao.cursor(dictionary=True)

    print("\n--- CADASTRAR NOVO PET ---")

    if not listar_tutores_disponiveis(cursor):
        cursor.close()
        conexao.close()
        return

    try:
        id_tutor = int(input("\nDigite o ID do tutor responsável: "))
    except ValueError:
        print("[ERRO] ID inválido.")
        cursor.close()
        conexao.close()
        return

    nome = input("Nome do Pet: ").strip()
    especie = input("Espécie/Raça (ex: Cachorro Poodle, Gato Siamês): ").strip()
    observacao = input("Observação (ex: Alérgico a shampoo comum): ").strip()
    entrada = input("Data de Nascimento (DD-MM-AAAA): ").strip()
    try:
        data_nascimento = datetime.strptime(entrada, "%d-%m-%Y").date()
    except ValueError:
        print("[ERRO] Data inválida. Use o formato DD-MM-AAAA.")
        cursor.close()
        conexao.close()
        return

    query = """
        INSERT INTO pet (nome, especie, observacao, data_nascimento, id_tutor)
        VALUES (%s, %s, %s, %s, %s)
    """
    valores = (nome, especie, observacao, data_nascimento, id_tutor)

    try:
        cursor.execute(query, valores)
        conexao.commit()
        print("\n[SUCESSO] Pet cadastrado e vinculado ao tutor com sucesso!")
    except mysql.connector.Error as err:
        print(f"\n[ERRO] Falha ao cadastrar. Verifique se o ID do tutor existe. Detalhes: {err}")
    finally:
        cursor.close()
        conexao.close()

def listar_pets():
    conexao = conectar_banco()
    cursor = conexao.cursor(dictionary=True)

    print("\n--- LISTA DE PETS ---")

    query = """
        SELECT p.id_pet, p.nome AS pet, p.especie,
               p.data_nascimento, c.nome AS tutor
        FROM pet p
        INNER JOIN tutor c ON p.id_tutor = c.id_tutor
    """
    cursor.execute(query)
    pets = cursor.fetchall()

    if not pets:
        print("Nenhum pet encontrado.")
    else:
        for p in pets:
            nascimento = p['data_nascimento'].strftime('%d-%m-%Y') if p['data_nascimento'] else '-'
            print(f"ID: {p['id_pet']} | Nome: {p['pet']} | Espécie: {p['especie']} | Nascimento: {nascimento} | Tutor Responsável: {p['tutor']}")

    cursor.close()
    conexao.close()

def excluir_pet():
    listar_pets()

    try:
        id_pet = int(input("\nDigite o ID do pet a ser excluído: "))
    except ValueError:
        print("[ERRO] ID inválido.")
        return

    conexao = conectar_banco()
    cursor = conexao.cursor(dictionary=True)

    try:
        cursor.execute("SELECT id_pet, nome FROM pet WHERE id_pet = %s", (id_pet,))
        pet = cursor.fetchone()

        if not pet:
            print("\n[AVISO] Pet não encontrado.")
            return

        confirmacao = input(f"Confirma a exclusão de '{pet['nome']}'? (S/N): ").strip().upper()
        if confirmacao != 'S':
            print("\nExclusão cancelada.")
            return

        cursor.execute("DELETE FROM pet WHERE id_pet = %s", (id_pet,))
        conexao.commit()
        print("\n[SUCESSO] Pet excluído com sucesso!")
    except mysql.connector.Error as err:
        conexao.rollback()
        print(f"\n[ERRO] Falha ao excluir. O pet esta vinculado a outro registro de agendamento.")
    finally:
        cursor.close()
        conexao.close()

def iniciar_modulo():
    while True:
        print("\n" + "="*45)
        print("   MÓDULO DE PETS ")
        print("="*45)
        print("1. Cadastrar Pet")
        print("2. Listar Pets")
        print("3. Excluir Pet")
        print("4. Voltar ao Painel Principal")

        opcao = input("\nEscolha uma opção: ").strip()

        if opcao == '1':
            cadastrar_pet()
        elif opcao == '2':
            listar_pets()
        elif opcao == '3':
            excluir_pet()
        elif opcao == '4':
            print("\nVoltando...")
            break
        else:
            print("\n[AVISO] Opção inválida!")

if __name__ == "__main__":
    iniciar_modulo()

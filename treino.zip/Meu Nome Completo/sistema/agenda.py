import mysql.connector
import sys
from datetime import datetime

def conectar_banco():
    try:
        return mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="saep_db"
        )
    except mysql.connector.Error as err:
        print(f"Erro ao conectar ao banco de dados: {err}")
        sys.exit(1)

def cadastrar_agendamento():
    conexao = conectar_banco()
    cursor = conexao.cursor(dictionary=True)

    print("\n--- NOVO AGENDAMENTO ---")

    cursor.execute("SELECT id_pet, nome FROM pet")
    pets = cursor.fetchall()

    if not pets:
        print("[AVISO] Nenhum pet encontrado. Cadastre um primeiro.")
        cursor.close()
        conexao.close()
        return

    print("Pets Disponíveis:")
    for p in pets:
        print(f"ID: {p['id_pet']} | Nome: {p['nome']}")

    try:
        id_pet = int(input("\nDigite o ID do Pet: "))
    except ValueError:
        print("[ERRO] ID inválido.")
        cursor.close()
        conexao.close()
        return

    entrada = input("Data e Hora (DD-MM-AAAA HH:MM): ").strip()
    try:
        data_agendamento = datetime.strptime(entrada, "%d-%m-%Y %H:%M")
    except ValueError:
        print("[ERRO] Data inválida. Use o formato DD-MM-AAAA HH:MM.")
        cursor.close()
        conexao.close()
        return

    motivo_servico = input("Serviço (Ex: Banho, Tosa, Consulta Veterinária): ").strip()

    query = """
        INSERT INTO agendamento (data_agendamento, motivo_servico, id_pet)
        VALUES (%s, %s, %s)
    """

    try:
        cursor.execute(query, (data_agendamento, motivo_servico, id_pet))
        conexao.commit()
        print("\n[SUCESSO] Agendamento incluído na lista com sucesso!")
    except mysql.connector.Error as err:
        print(f"\n[ERRO] Falha ao agendar: {err}")
    finally:
        cursor.close()
        conexao.close()

def listar_agendamentos():
    conexao = conectar_banco()
    cursor = conexao.cursor(dictionary=True)

    print("\n--- LISTA DE AGENDAMENTOS ---")

    query = """
        SELECT
            a.id_agendamento,
            a.data_agendamento,
            a.motivo_servico,
            p.nome AS pet_nome,
            t.nome AS tutor_nome,
            t.telefone AS tutor_telefone
        FROM agendamento a
        INNER JOIN pet p ON a.id_pet = p.id_pet
        INNER JOIN tutor t ON p.id_tutor = t.id_tutor
        ORDER BY a.data_agendamento ASC
    """

    cursor.execute(query)
    agendamentos = cursor.fetchall()

    if not agendamentos:
        print("Nenhum agendamento encontrado.")
    else:
        for a in agendamentos:
            data_formatada = a['data_agendamento'].strftime('%d-%m-%Y %H:%M')
            print(f"ID: {a['id_agendamento']} | Data: {data_formatada} | Serviço: {a['motivo_servico']}")
            print(f"    -> Pet: {a['pet_nome']}")
            print(f"    -> tutor (Tutor): {a['tutor_nome']} | Tel: {a['tutor_telefone']}")
            print("-" * 50)

    cursor.close()
    conexao.close()

def atualizar_data_agendamento():
    print("\n--- REAGENDAR ---")
    listar_agendamentos()

    try:
        id_agendamento = int(input("\nDigite o ID do agendamento que deseja alterar: "))
    except ValueError:
        print("[ERRO] ID inválido.")
        return

    entrada = input("Nova Data (DD-MM-AAAA) ou Data e Hora (DD-MM-AAAA HH:MM): ").strip()

    conexao = conectar_banco()
    cursor = conexao.cursor()

    try:
        nova_data = datetime.strptime(entrada, "%d-%m-%Y %H:%M")
    except ValueError:
        try:
            somente_data = datetime.strptime(entrada, "%d-%m-%Y")
        except ValueError:
            print("[ERRO] Data inválida. Use DD-MM-AAAA ou DD-MM-AAAA HH:MM.")
            cursor.close()
            conexao.close()
            return
        cursor.execute("SELECT data_agendamento FROM agendamento WHERE id_agendamento = %s", (id_agendamento,))
        atual = cursor.fetchone()
        if not atual:
            print("\n[AVISO] Nenhum agendamento encontrado com este ID.")
            cursor.close()
            conexao.close()
            return
        nova_data = somente_data.replace(hour=atual[0].hour, minute=atual[0].minute)

    query = "UPDATE agendamento SET data_agendamento = %s WHERE id_agendamento = %s"

    try:
        cursor.execute(query, (nova_data, id_agendamento))
        conexao.commit()
        if cursor.rowcount > 0:
            print("\n[SUCESSO] Data do agendamento atualizada com sucesso!")
        else:
            print("\n[AVISO] Nenhum agendamento encontrado com este ID.")
    except mysql.connector.Error as err:
        print(f"\n[ERRO] Falha ao atualizar data: {err}")
    finally:
        cursor.close()
        conexao.close()

def excluir_agendamento():
    print("\n--- EXCLUIR AGENDAMENTO ---")
    listar_agendamentos()

    try:
        id_agendamento = int(input("\nDigite o ID do agendamento que deseja excluir: "))
    except ValueError:
        print("[ERRO] ID inválido.")
        return

    conexao = conectar_banco()
    cursor = conexao.cursor(dictionary=True)

    try:
        cursor.execute(
            "SELECT id_agendamento, data_agendamento, motivo_servico FROM agendamento WHERE id_agendamento = %s",
            (id_agendamento,)
        )
        agendamento = cursor.fetchone()

        if not agendamento:
            print("\n[AVISO] Nenhum agendamento encontrado com este ID.")
            return

        data_formatada = agendamento['data_agendamento'].strftime('%d-%m-%Y %H:%M')
        confirmacao = input(
            f"Confirma a exclusão do agendamento de {data_formatada} ({agendamento['motivo_servico']})? (S/N): "
        ).strip().upper()
        if confirmacao != 'S':
            print("\nExclusão cancelada.")
            return

        cursor.execute("DELETE FROM agendamento WHERE id_agendamento = %s", (id_agendamento,))
        conexao.commit()
        print("\n[SUCESSO] Agendamento excluído com sucesso!")
    except mysql.connector.Error as err:
        conexao.rollback()
        print(f"\n[ERRO] Falha ao excluir agendamento: {err}")
    finally:
        cursor.close()
        conexao.close()

def iniciar_modulo():
    while True:
        print("\n" + "="*45)
        print("   MÓDULO DE AGENDAMENTOS")
        print("="*45)
        print("1. Cadastrar Novo Agendamento")
        print("2. Listar Todos os Agendamentos")
        print("3. Atualizar Data do Agendamento")
        print("4. Excluir Agendamento")
        print("5. Voltar ao Painel Principal")

        opcao = input("\nEscolha uma opção: ").strip()

        if opcao == '1':
            cadastrar_agendamento()
        elif opcao == '2':
            listar_agendamentos()
        elif opcao == '3':
            atualizar_data_agendamento()
        elif opcao == '4':
            excluir_agendamento()
        elif opcao == '5':
            print("\nVoltando...")
            break
        else:
            print("\n[AVISO] Opção inválida!")

if __name__ == "__main__":
    iniciar_modulo()

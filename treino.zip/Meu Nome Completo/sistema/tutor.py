import mysql.connector
import base64
import sys

def conectar_banco():
    try:
        return mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="saep_db"
        )
    except mysql.connector.Error as err:
        print(f"Erro ao conectar ao banco de dados: {err}")
        sys.exit(1)

def criptografar_dado(dado):
    return base64.b64encode(dado.encode('utf-8')).decode('utf-8')

def descriptografar_dado(dado_criptografado):
    try:
        return base64.b64decode(dado_criptografado).decode('utf-8')
    except Exception:
        return dado_criptografado

def listar_tutores(termo_busca=""):
    conexao = conectar_banco()
    cursor = conexao.cursor(dictionary=True)

    print("\n--- LISTA DE tutores ---")

    if termo_busca:
        query = "SELECT * FROM tutor WHERE nome LIKE %s OR email LIKE %s"
        cursor.execute(query, (f"%{termo_busca}%", f"%{termo_busca}%"))
    else:
        query = "SELECT * FROM tutor"
        cursor.execute(query)

    tutores = cursor.fetchall()

    if not tutores:
        print("Nenhum tutor encontrado.")
    else:
        for c in tutores:
            cpf_mascarado = descriptografar_dado(c['cpf'])
            print(f"ID: {c['id_tutor']} | Nome: {c['nome']} | CPF: {cpf_mascarado} | Tel: {c['telefone']} | E-mail: {c['email']}")

    cursor.close()
    conexao.close()

def cadastrar_tutor():
    print("\n--- CADASTRAR NOVO TUTOR ---")
    nome = input("Nome: ").strip()
    cpf = input("CPF (somente números): ").strip()
    telefone = input("Telefone: ").strip()
    email = input("E-mail: ").strip()

    cpf_criptografado = criptografar_dado(cpf)

    conexao = conectar_banco()
    cursor = conexao.cursor()

    query = "INSERT INTO tutor (nome, cpf, telefone, email) VALUES (%s, %s, %s, %s)"
    valores = (nome, cpf_criptografado, telefone, email)

    try:
        cursor.execute(query, valores)
        conexao.commit()
        print("\n[SUCESSO] Tutor cadastrado com sucesso! A lista foi atualizada.")
    except mysql.connector.Error as err:
        print(f"\n[ERRO] Falha ao cadastrar: {err}")
    finally:
        cursor.close()
        conexao.close()

def editar_tutor():
    print("\n--- ATUALIZAR TUTOR ---")
    listar_tutores()

    try:
        id_tutor = int(input("\nDigite o ID do tutor que deseja editar: "))
    except ValueError:
        print("[ERRO] ID inválido.")
        return

    nome = input("Novo Nome: ").strip()
    cpf = input("Novo CPF: ").strip()
    telefone = input("Novo Telefone: ").strip()
    email = input("Novo E-mail: ").strip()

    cpf_criptografado = criptografar_dado(cpf)

    conexao = conectar_banco()
    cursor = conexao.cursor()

    query = "UPDATE tutor SET nome = %s, cpf = %s, telefone = %s, email = %s WHERE id_tutor = %s"
    valores = (nome, cpf_criptografado, telefone, email, id_tutor)

    try:
        cursor.execute(query, valores)
        conexao.commit()
        if cursor.rowcount > 0:
            print("\n[SUCESSO] Dados do tutor atualizados com sucesso!")
        else:
            print("\n[AVISO] Nenhum tutor encontrado com este ID.")
    except mysql.connector.Error as err:
        print(f"\n[ERRO] Falha ao atualizar: {err}")
    finally:
        cursor.close()
        conexao.close()

def excluir_tutor():
    print("\n--- EXCLUIR TUTOR ---")
    listar_tutores()

    try:
        id_tutor = int(input("\nDigite o ID do tutor que deseja excluir: "))
    except ValueError:
        print("[ERRO] ID inválido.")
        return

    conexao = conectar_banco()
    cursor = conexao.cursor()

    query = "DELETE FROM tutor WHERE id_tutor = %s"

    try:
        cursor.execute(query, (id_tutor,))
        conexao.commit()
        if cursor.rowcount > 0:
            print("\n[SUCESSO] tutor excluído com sucesso!")
        else:
            print("\n[AVISO] Nenhum tutor encontrado com este ID.")
    except mysql.connector.Error as err:
        print(f"\n[ERRO] Falha ao excluir (Verifique se há pets vinculados)")
    finally:
        cursor.close()
        conexao.close()

def iniciar_modulo():
    while True:
        print("\n" + "="*40)
        print("   MÓDULO DE tutores   ")
        print("-"*40)
        print("1. Cadastrar tutor")
        print("2. Listar tutores")
        print("3. Buscar tutor")
        print("4. Editar tutor")
        print("5. Excluir tutor")
        print("6. Voltar ao Painel Principal")
        print("="*40)

        opcao = input("\nEscolha uma opção: ").strip()

        if opcao == '1':
            cadastrar_tutor()
        elif opcao == '2':
            listar_tutores()
        elif opcao == '3':
            termo = input("\nDigite o nome ou e-mail para buscar: ").strip()
            listar_tutores(termo_busca=termo)
        elif opcao == '4':
            editar_tutor()
        elif opcao == '5':
            excluir_tutor()
        elif opcao == '6':
            print("\nVoltando...")
            break
        else:
            print("\n[AVISO] Opção inválida!")

if __name__ == "__main__":
    iniciar_modulo()

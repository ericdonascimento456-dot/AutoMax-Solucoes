CREATE DATABASE IF NOT EXISTS saep_db;
USE saep_db;

CREATE TABLE usuario (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL
);

CREATE TABLE tutor (
    id_tutor INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cpf VARCHAR(255) NOT NULL,
    telefone VARCHAR(20),
    email VARCHAR(100)
);

CREATE TABLE pet (
    id_pet INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    especie VARCHAR(50),
    observacao VARCHAR(50),
    data_nascimento DATE,
    id_tutor INT NOT NULL,
    FOREIGN KEY (id_tutor) REFERENCES tutor(id_tutor)
);

CREATE TABLE agendamento (
    id_agendamento INT AUTO_INCREMENT PRIMARY KEY,
    data_agendamento DATETIME NOT NULL,
    motivo_servico VARCHAR(255),
    id_pet INT NOT NULL,
    FOREIGN KEY (id_pet) REFERENCES pet(id_pet)
);

INSERT INTO usuario (nome, email, senha) VALUES
('Admin', 'admin@email.com', '$2b$12$tfyH8TQUTnjG7DqKfinGhemOJuywCLsK/n5P95Ubj5qU02jp.FkI.'),
('Carlos', 'carlos@email.com', '$2b$12$TDaMDje5IxhNb6QhKvbuvOSC1TZUQnJ.vTj6gzTlicJQGHuzTrCJS'),
('Marcos', 'marcos@email.com', '$2b$12$7hfLDPIRIWSk2xqfo3xltO82FXJF6TqXAOcOSWemjLBWGhhycCf6m');

INSERT INTO tutor (nome, cpf, telefone, email) VALUES
('Roberto Silva', 'dGVzdGVfY3JpcHRvZ3JhZmlhX2NwZl8wMDE=', '47999990001', 'roberto@email.com'),
('Fernando Souza', 'dGVzdGVfY3JpcHRvZ3JhZmlhX2NwZl8wMDI=', '47999990002', 'fernando@email.com'),
('Lucas Pereira', 'dGVzdGVfY3JpcHRvZ3JhZmlhX2NwZl8wMDM=', '47999990003', 'lucas@email.com');

INSERT INTO pet (nome, especie, observacao, data_nascimento, id_tutor) VALUES
('Thor', 'Cachorro Golden Retriever', 'Banho e tosa higiênica', '2019-05-20', 1),
('Mel', 'Gato Siamês', 'Alérgica a shampoo comum', '2021-08-12', 2),
('Bolinha', 'Cachorro Poodle', 'Tosa na tesoura', '2018-11-30', 3);

INSERT INTO agendamento (data_agendamento, motivo_servico, id_pet) VALUES
('2026-10-20 14:00:00', 'Banho e Tosa Higiênica', 1),
('2026-10-21 10:30:00', 'Banho Hipoalergênico', 2),
('2026-10-22 16:00:00', 'Tosa na Tesoura e Hidratação', 3);

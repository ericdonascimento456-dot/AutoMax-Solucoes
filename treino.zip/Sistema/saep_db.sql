-- Criação do Banco de Dados
CREATE DATABASE IF NOT EXISTS saep_db;
USE saep_db;

-- 1. Criação da Tabela USUARIO (Independente)
CREATE TABLE usuario (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL 
);

-- 2. Criação da Tabela CLIENTE (Titular / tutor do pet)
CREATE TABLE cliente (
    id_cliente INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cpf VARCHAR(255) NOT NULL, 
    telefone VARCHAR(20),
    email VARCHAR(100)
);

-- 3. Criação da Tabela DEPENDENTE (o pet; parentesco guarda espécie/raça)
CREATE TABLE dependente (
    id_dependente INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    parentesco VARCHAR(50),
    observacao VARCHAR(50),
    data_nascimento DATE,
    id_cliente INT NOT NULL,
    FOREIGN KEY (id_cliente) REFERENCES cliente(id_cliente)
);

-- 4. Criação da Tabela AGENDAMENTO
CREATE TABLE agendamento (
    id_agendamento INT AUTO_INCREMENT PRIMARY KEY,
    data_agendamento DATETIME NOT NULL,
    motivo_servico VARCHAR(255),
    id_dependente INT NOT NULL,
    FOREIGN KEY (id_dependente) REFERENCES dependente(id_dependente)
);

-- POPULAÇÃO DO BANCO DE DADOS

-- Inserindo 3 Usuários Admins - Senhas com hash bcrypt (123, 456, 789)
INSERT INTO usuario (nome, email, senha) VALUES
('Admin', 'admin@email.com', '$2b$12$tfyH8TQUTnjG7DqKfinGhemOJuywCLsK/n5P95Ubj5qU02jp.FkI.'),
('Carlos', 'carlos@email.com', '$2b$12$TDaMDje5IxhNb6QhKvbuvOSC1TZUQnJ.vTj6gzTlicJQGHuzTrCJS'),
('Marcos', 'marcos@email.com', '$2b$12$7hfLDPIRIWSk2xqfo3xltO82FXJF6TqXAOcOSWemjLBWGhhycCf6m');

-- Inserindo 3 Clientes Titulares - CPFs simulando Criptografia
INSERT INTO cliente (nome, cpf, telefone, email) VALUES
('Roberto Silva', 'dGVzdGVfY3JpcHRvZ3JhZmlhX2NwZl8wMDE=', '47999990001', 'roberto@email.com'),
('Fernando Souza', 'dGVzdGVfY3JpcHRvZ3JhZmlhX2NwZl8wMDI=', '47999990002', 'fernando@email.com'),
('Lucas Pereira', 'dGVzdGVfY3JpcHRvZ3JhZmlhX2NwZl8wMDM=', '47999990003', 'lucas@email.com');

-- Inserindo 3 Dependentes / pets (Associados aos clientes acima)
INSERT INTO dependente (nome, parentesco, observacao, data_nascimento, id_cliente) VALUES
('Thor', 'Cachorro - Golden Retriever', 'Banho e tosa higiênica', '2019-05-20', 1),
('Mel', 'Gato - Siamês', 'Consulta veterinária de rotina', '2021-08-12', 2),
('Bob', 'Cachorro - Poodle', 'Vacina V10 e banho', '2020-11-30', 3);

-- Inserindo 3 Agendamentos (Associados aos dependentes acima)
INSERT INTO agendamento (data_agendamento, motivo_servico, id_dependente) VALUES
('2026-10-20 14:00:00', 'Banho e Tosa Higiênica', 1),
('2026-10-21 10:30:00', 'Consulta Veterinária de Rotina', 2),
('2026-10-22 16:00:00', 'Vacinação V10 e Banho', 3);



import mysql.connector
import bcrypt
import sys
import main
from datetime import datetime, timedelta

# Configuração da "Sessão" em memória para o ambiente de terminal
sessao_ativa = {
    "id_usuario": None,
    "nome": None,
    "expira_em": None
}

def conectar_banco():
    try:
        return mysql.connector.connect(
            host="localhost", # Insira o endereço do seu banco
            user="root",  # Insira o usuário do seu banco
            password="",  # Insira a senha do seu banco
            database="saep_db" # Insira o nome do seu banco
        )
    except mysql.connector.Error as err:
        print(f"Erro ao conectar ao banco de dados: {err}")
        sys.exit(1)

def realizar_login():
    conexao = conectar_banco()
    cursor = conexao.cursor(dictionary=True)
    
    while True:
        print("\n--- LOGIN DO SISTEMA ---")
        email_digitado = input("E-mail: ").strip()
        senha_digitada = input("Senha: ").strip()
        
        # Busca o usuário no banco pelo email
        query = "SELECT id_usuario, nome, senha FROM usuario WHERE email = %s"
        cursor.execute(query, (email_digitado,))
        usuario = cursor.fetchone()
        
        # Validação de falha de autenticação (backend/terminal)
        if usuario:
            # Compara a senha digitada com o hash bcrypt salvo no banco
            try:
                senha_valida = bcrypt.checkpw(senha_digitada.encode('utf-8'), usuario['senha'].encode('utf-8'))
            except ValueError:
                # O valor salvo no banco não é um hash bcrypt válido
                senha_valida = False

            if senha_valida:
                # Criando a sessão com expiração de 10 minutos
                sessao_ativa["id_usuario"] = usuario["id_usuario"]
                sessao_ativa["nome"] = usuario["nome"]
                sessao_ativa["expira_em"] = datetime.now() + timedelta(minutes=10)
                
                print(f"\n[SUCESSO] Autenticação realizada. Bem-vindo, {usuario['nome']}!")
                main.exibir_painel_principal(sessao_ativa)
                break
            else:
                print("[ERRO] Senha incorreta. Tente novamente.")
        else:
            print("[ERRO] E-mail não encontrado. Tente novamente.")
            
    cursor.close()
    conexao.close()

def verificar_sessao():
    if not sessao_ativa.get("id_usuario"):
        print("Acesso negado. Faça o login primeiro.")
        return False
    
    if datetime.now() > sessao_ativa["expira_em"]:
        print("\n[AVISO] Sua sessão expirou. Por favor, faça login novamente.")
        sessao_ativa["id_usuario"] = None
        sessao_ativa["nome"] = None
        sessao_ativa["expira_em"] = None
        return False
        
    return True

def funcionalidade_principal():
    print(f"\n--- PAINEL PRINCIPAL ---")
    print(f"Usuário Logado: {sessao_ativa['nome']}")
    print(f"Sessão válida até: {sessao_ativa['expira_em'].strftime('%H:%M:%S')}")
    print("1. Acessar Clientes")
    print("2. Sair do Sistema")
    input("Pressione Enter para continuar...")

if __name__ == "__main__":
    realizar_login()
    
    if verificar_sessao():
        funcionalidade_principal()

import mysql.connector
from datetime import datetime
import sys

def conectar_banco():
    try:
        return mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="saep_db"
        )
    except mysql.connector.Error as err:
        print(f"Erro ao conectar ao banco de dados: {err}")
        sys.exit(1)

def listar_clientes_disponiveis(cursor):
    #Auxiliar para exibir os clientes titulares disponíveis para associação.
    cursor.execute("SELECT id_cliente, nome FROM cliente")
    clientes = cursor.fetchall()
    
    if not clientes:
        print("Nenhum cliente titular encontrado. Cadastre um cliente primeiro.")
        return False
        
    print("\n--- CLIENTES TITULARES DISPONÍVEIS ---")
    for c in clientes:
        print(f"ID: {c['id_cliente']} | Nome: {c['nome']}")
    print("-" * 38)
    return True

def cadastrar_dependente():
    #Realiza a inserção de um novo dependente, associando-o a um cliente, criando a vinculação obrigatória.
    conexao = conectar_banco()
    cursor = conexao.cursor(dictionary=True)
    
    print("\n--- CADASTRAR NOVO DEPENDENTE ---")
    
    # Lista os titulares para garantir a integridade referencial
    if not listar_clientes_disponiveis(cursor):
        cursor.close()
        conexao.close()
        return

    try:
        id_cliente = int(input("\nDigite o ID do cliente titular responsável: "))
    except ValueError:
        print("[ERRO] ID inválido.")
        cursor.close()
        conexao.close()
        return

    nome = input("Nome do Pet: ").strip()
    parentesco = input("Espécie/Raça (ex: Cachorro - Poodle): ").strip()
    observacao = input("Observação (ex: Banho e tosa): ").strip()
    entrada = input("Data de Nascimento (DD-MM-AAAA): ").strip()
    try:
        data_nascimento = datetime.strptime(entrada, "%d-%m-%Y").date()
    except ValueError:
        print("[ERRO] Data inválida. Use o formato DD-MM-AAAA.")
        cursor.close()
        conexao.close()
        return
    
    query = """
        INSERT INTO dependente (nome, parentesco, observacao, data_nascimento, id_cliente) 
        VALUES (%s, %s, %s, %s, %s)
    """
    valores = (nome, parentesco, observacao, data_nascimento, id_cliente)
    
    try:
        cursor.execute(query, valores)
        conexao.commit()
        print("\n[SUCESSO] Dependente cadastrado e vinculado ao cliente com sucesso!")
    except mysql.connector.Error as err:
        print(f"\n[ERRO] Falha ao cadastrar. Verifique se o ID do cliente existe. Detalhes: {err}")
    finally:
        cursor.close()
        conexao.close()

def listar_dependentes():
    #Lista todos os dependentes cadastrados e seus respectivos titulares.
    conexao = conectar_banco()
    cursor = conexao.cursor(dictionary=True)
    
    print("\n--- LISTA DE DEPENDENTES ---")
    
    query = """
        SELECT d.id_dependente, d.nome AS dependente, d.parentesco, 
               d.data_nascimento, c.nome AS titular 
        FROM dependente d
        INNER JOIN cliente c ON d.id_cliente = c.id_cliente
    """
    cursor.execute(query)
    dependentes = cursor.fetchall()
    
    if not dependentes:
        print("Nenhum dependente encontrado.")
    else:
        for d in dependentes:
            nascimento = d['data_nascimento'].strftime('%d-%m-%Y') if d['data_nascimento'] else '-'
            print(f"ID: {d['id_dependente']} | Nome: {d['dependente']} | Espécie/Raça: {d['parentesco']} | Nascimento: {nascimento} | Titular Responsável: {d['titular']}")
            
    cursor.close()
    conexao.close()

def excluir_dependente():
    #Exclui um dependente do banco de dados após confirmação.
    listar_dependentes()

    try:
        id_dependente = int(input("\nDigite o ID do dependente a ser excluído: "))
    except ValueError:
        print("[ERRO] ID inválido.")
        return

    conexao = conectar_banco()
    cursor = conexao.cursor(dictionary=True)

    try:
        cursor.execute("SELECT id_dependente, nome FROM dependente WHERE id_dependente = %s", (id_dependente,))
        dependente = cursor.fetchone()

        if not dependente:
            print("\n[AVISO] Dependente não encontrado.")
            return

        confirmacao = input(f"Confirma a exclusão de '{dependente['nome']}'? (S/N): ").strip().upper()
        if confirmacao != 'S':
            print("\nExclusão cancelada.")
            return

        cursor.execute("DELETE FROM dependente WHERE id_dependente = %s", (id_dependente,))
        conexao.commit()
        print("\n[SUCESSO] Dependente excluído com sucesso!")
    except mysql.connector.Error as err:
        conexao.rollback()
        print(f"\n[ERRO] Falha ao excluir. O dependente esta vinculado a outro registro de agendamento.")
    finally:
        cursor.close()
        conexao.close()

def iniciar_modulo():
    #Menu principal do módulo de dependentes.
    while True:
        print("\n" + "="*45)
        print("   MÓDULO DE DEPENDENTES ")
        print("="*45)
        print("1. Cadastrar Dependente")
        print("2. Listar Dependentes")
        print("3. Excluir Dependente")
        print("4. Voltar ao Painel Principal")
        
        opcao = input("\nEscolha uma opção: ").strip()
        
        if opcao == '1':
            cadastrar_dependente()
        elif opcao == '2':
            listar_dependentes()
        elif opcao == '3':
            excluir_dependente()
        elif opcao == '4':
            print("\nVoltando...")
            break
        else:
            print("\n[AVISO] Opção inválida!")

if __name__ == "__main__":
    iniciar_modulo()

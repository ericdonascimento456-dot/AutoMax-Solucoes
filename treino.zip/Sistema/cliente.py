import mysql.connector
import base64
import sys

def conectar_banco():
    try:
        return mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="saep_db"
        )
    except mysql.connector.Error as err:
        print(f"Erro ao conectar ao banco de dados: {err}")
        sys.exit(1)

def criptografar_dado(dado):
    #Simula a criptografia de um dado sensível (LGPD).
    return base64.b64encode(dado.encode('utf-8')).decode('utf-8')

def descriptografar_dado(dado_criptografado):
    #Reverte a criptografia para exibição, se necessário.
    try:
        return base64.b64decode(dado_criptografado).decode('utf-8')
    except Exception:
        return dado_criptografado

def listar_clientes(termo_busca=""):
    #Lista os clientes cadastrados. Se um termo for passado, realiza a busca atualizando os resultados conforme exigido.
    conexao = conectar_banco()
    cursor = conexao.cursor(dictionary=True)
    
    print("\n--- LISTA DE CLIENTES ---")
    
    if termo_busca:
        # Recurso de busca por termo específico
        query = "SELECT * FROM cliente WHERE nome LIKE %s OR email LIKE %s"
        cursor.execute(query, (f"%{termo_busca}%", f"%{termo_busca}%"))
    else:
        # Listagem padrão exibindo os registros iniciais
        query = "SELECT * FROM cliente"
        cursor.execute(query)
        
    clientes = cursor.fetchall()
    
    if not clientes:
        print("Nenhum cliente encontrado.")
    else:
        for c in clientes:
            cpf_mascarado = descriptografar_dado(c['cpf'])
            print(f"ID: {c['id_cliente']} | Nome: {c['nome']} | CPF: {cpf_mascarado} | Tel: {c['telefone']} | E-mail: {c['email']}")
            
    cursor.close()
    conexao.close()

def cadastrar_cliente():
    #Realiza a inserção de um novo cliente com criptografia do CPF.
    print("\n--- CADASTRAR NOVO CLIENTE ---")
    nome = input("Nome: ").strip()
    cpf = input("CPF (somente números): ").strip()
    telefone = input("Telefone: ").strip()
    email = input("E-mail: ").strip()
    
    cpf_criptografado = criptografar_dado(cpf)
    
    conexao = conectar_banco()
    cursor = conexao.cursor()
    
    query = "INSERT INTO cliente (nome, cpf, telefone, email) VALUES (%s, %s, %s, %s)"
    valores = (nome, cpf_criptografado, telefone, email)
    
    try:
        cursor.execute(query, valores)
        conexao.commit()
        print("\n[SUCESSO] Cliente cadastrado com sucesso! A lista foi atualizada.")
    except mysql.connector.Error as err:
        print(f"\n[ERRO] Falha ao cadastrar: {err}")
    finally:
        cursor.close()
        conexao.close()

def editar_cliente():
    #Edita os dados de um cliente já existente no banco de dados.
    print("\n--- ATUALIZAR CLIENTE ---")
    listar_clientes()
    
    try:
        id_cliente = int(input("\nDigite o ID do cliente que deseja editar: "))
    except ValueError:
        print("[ERRO] ID inválido.")
        return
        
    nome = input("Novo Nome: ").strip()
    cpf = input("Novo CPF: ").strip()
    telefone = input("Novo Telefone: ").strip()
    email = input("Novo E-mail: ").strip()
    
    cpf_criptografado = criptografar_dado(cpf)
    
    conexao = conectar_banco()
    cursor = conexao.cursor()
    
    query = "UPDATE cliente SET nome = %s, cpf = %s, telefone = %s, email = %s WHERE id_cliente = %s"
    valores = (nome, cpf_criptografado, telefone, email, id_cliente)
    
    try:
        cursor.execute(query, valores)
        conexao.commit()
        if cursor.rowcount > 0:
            print("\n[SUCESSO] Dados do cliente atualizados com sucesso!")
        else:
            print("\n[AVISO] Nenhum cliente encontrado com este ID.")
    except mysql.connector.Error as err:
        print(f"\n[ERRO] Falha ao atualizar: {err}")
    finally:
        cursor.close()
        conexao.close()

def excluir_cliente():
    #Exclui o cliente selecionado com base no ID.
    print("\n--- EXCLUIR CLIENTE ---")
    listar_clientes()
    
    try:
        id_cliente = int(input("\nDigite o ID do cliente que deseja excluir: "))
    except ValueError:
        print("[ERRO] ID inválido.")
        return
        
    conexao = conectar_banco()
    cursor = conexao.cursor()
    
    query = "DELETE FROM cliente WHERE id_cliente = %s"
    
    try:
        cursor.execute(query, (id_cliente,))
        conexao.commit()
        if cursor.rowcount > 0:
            print("\n[SUCESSO] Cliente excluído com sucesso!")
        else:
            print("\n[AVISO] Nenhum cliente encontrado com este ID.")
    except mysql.connector.Error as err:
        print(f"\n[ERRO] Falha ao excluir (Verifique se há dependentes vinculados)")
    finally:
        cursor.close()
        conexao.close()

def iniciar_modulo():
    """Menu principal do módulo de clientes."""
    while True:
        print("\n" + "="*40)
        print("   MÓDULO DE CLIENTES   ")
        print("-"*40)
        print("1. Cadastrar Cliente")
        print("2. Listar Clientes")
        print("3. Buscar Cliente")
        print("4. Editar Cliente")
        print("5. Excluir Cliente")
        print("6. Voltar ao Painel Principal")
        print("="*40)
        
        opcao = input("\nEscolha uma opção: ").strip()
        
        if opcao == '1':
            cadastrar_cliente()
        elif opcao == '2':
            listar_clientes()
        elif opcao == '3':
            termo = input("\nDigite o nome ou e-mail para buscar: ").strip()
            listar_clientes(termo_busca=termo)
        elif opcao == '4':
            editar_cliente()
        elif opcao == '5':
            excluir_cliente()
        elif opcao == '6':
            print("\nVoltando...")
            break
        else:
            print("\n[AVISO] Opção inválida!")

if __name__ == "__main__":
    iniciar_modulo()

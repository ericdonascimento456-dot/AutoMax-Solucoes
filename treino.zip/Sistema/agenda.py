import mysql.connector
import sys
from datetime import datetime

def conectar_banco():
    try:
        return mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="saep_db"
        )
    except mysql.connector.Error as err:
        print(f"Erro ao conectar ao banco de dados: {err}")
        sys.exit(1)

def cadastrar_agendamento():
    #Realiza a inserção de um novo agendamento vinculado a um dependente.
    conexao = conectar_banco()
    cursor = conexao.cursor(dictionary=True)
    
    print("\n--- NOVO AGENDAMENTO ---")
    
    # Exibe dependentes para facilitar a escolha do ID
    cursor.execute("SELECT id_dependente, nome FROM dependente")
    dependentes = cursor.fetchall()
    
    if not dependentes:
        print("[AVISO] Nenhum dependente encontrado. Cadastre um primeiro.")
        cursor.close()
        conexao.close()
        return
        
    print("Dependentes Disponíveis:")
    for d in dependentes:
        print(f"ID: {d['id_dependente']} | Nome: {d['nome']}")
        
    try:
        id_dependente = int(input("\nDigite o ID do Dependente: "))
    except ValueError:
        print("[ERRO] ID inválido.")
        cursor.close()
        conexao.close()
        return

    entrada = input("Data e Hora (DD-MM-AAAA HH:MM): ").strip()
    try:
        data_agendamento = datetime.strptime(entrada, "%d-%m-%Y %H:%M")
    except ValueError:
        print("[ERRO] Data inválida. Use o formato DD-MM-AAAA HH:MM.")
        cursor.close()
        conexao.close()
        return

    motivo_servico = input("Serviço (Ex: Banho e Tosa, Vacina): ").strip()
    
    query = """
        INSERT INTO agendamento (data_agendamento, motivo_servico, id_dependente) 
        VALUES (%s, %s, %s)
    """
    
    try:
        cursor.execute(query, (data_agendamento, motivo_servico, id_dependente))
        conexao.commit()
        print("\n[SUCESSO] Agendamento incluído na lista com sucesso!")
    except mysql.connector.Error as err:
        print(f"\n[ERRO] Falha ao agendar: {err}")
    finally:
        cursor.close()
        conexao.close()

def listar_agendamentos():
    #Lista os agendamentos trazendo todos os dados do cliente e do dependente.
    conexao = conectar_banco()
    cursor = conexao.cursor(dictionary=True)
    
    print("\n--- LISTA DE AGENDAMENTOS ---")
    
    # A ordenação 'ORDER BY a.data_agendamento ASC' atende à ordenação por dia.
    # Para mês, você usaria na última linha: ORDER BY MONTH(a.data_agendamento) ASC
    # Para ano, você usaria na última linha: ORDER BY YEAR(a.data_agendamento) ASC
    query = """
        SELECT 
            a.id_agendamento, 
            a.data_agendamento, 
            a.motivo_servico,
            d.nome AS dependente_nome,
            c.nome AS cliente_nome,
            c.telefone AS cliente_telefone
        FROM agendamento a
        INNER JOIN dependente d ON a.id_dependente = d.id_dependente
        INNER JOIN cliente c ON d.id_cliente = c.id_cliente
        ORDER BY a.data_agendamento ASC
    """
    
    cursor.execute(query)
    agendamentos = cursor.fetchall()
    
    if not agendamentos:
        print("Nenhum agendamento encontrado.")
    else:
        for a in agendamentos:
            data_formatada = a['data_agendamento'].strftime('%d-%m-%Y %H:%M')
            print(f"ID: {a['id_agendamento']} | Data: {data_formatada} | Serviço: {a['motivo_servico']}")
            print(f"    -> Pet: {a['dependente_nome']}")
            print(f"    -> Cliente (Titular): {a['cliente_nome']} | Tel: {a['cliente_telefone']}")
            print("-" * 50)
            
    cursor.close()
    conexao.close()

def atualizar_data_agendamento():
    #Atualiza exclusivamente a data de um agendamento já cadastrado.
    print("\n--- REAGENDAR ---")
    listar_agendamentos()
    
    try:
        id_agendamento = int(input("\nDigite o ID do agendamento que deseja alterar: "))
    except ValueError:
        print("[ERRO] ID inválido.")
        return
        
    entrada = input("Nova Data (DD-MM-AAAA) ou Data e Hora (DD-MM-AAAA HH:MM): ").strip()
    
    conexao = conectar_banco()
    cursor = conexao.cursor()
    
    try:
        nova_data = datetime.strptime(entrada, "%d-%m-%Y %H:%M")
    except ValueError:
        try:
            # Só a data foi informada: mantém a hora atual do agendamento
            somente_data = datetime.strptime(entrada, "%d-%m-%Y")
        except ValueError:
            print("[ERRO] Data inválida. Use DD-MM-AAAA ou DD-MM-AAAA HH:MM.")
            cursor.close()
            conexao.close()
            return
        cursor.execute("SELECT data_agendamento FROM agendamento WHERE id_agendamento = %s", (id_agendamento,))
        atual = cursor.fetchone()
        if not atual:
            print("\n[AVISO] Nenhum agendamento encontrado com este ID.")
            cursor.close()
            conexao.close()
            return
        nova_data = somente_data.replace(hour=atual[0].hour, minute=atual[0].minute)
    
    query = "UPDATE agendamento SET data_agendamento = %s WHERE id_agendamento = %s"
    
    try:
        cursor.execute(query, (nova_data, id_agendamento))
        conexao.commit()
        if cursor.rowcount > 0:
            print("\n[SUCESSO] Data do agendamento atualizada com sucesso!")
        else:
            print("\n[AVISO] Nenhum agendamento encontrado com este ID.")
    except mysql.connector.Error as err:
        print(f"\n[ERRO] Falha ao atualizar data: {err}")
    finally:
        cursor.close()
        conexao.close()

def excluir_agendamento():
    #Exclui um agendamento do banco de dados após confirmação.
    print("\n--- EXCLUIR AGENDAMENTO ---")
    listar_agendamentos()

    try:
        id_agendamento = int(input("\nDigite o ID do agendamento que deseja excluir: "))
    except ValueError:
        print("[ERRO] ID inválido.")
        return

    conexao = conectar_banco()
    cursor = conexao.cursor(dictionary=True)

    try:
        cursor.execute(
            "SELECT id_agendamento, data_agendamento, motivo_servico FROM agendamento WHERE id_agendamento = %s",
            (id_agendamento,)
        )
        agendamento = cursor.fetchone()

        if not agendamento:
            print("\n[AVISO] Nenhum agendamento encontrado com este ID.")
            return

        data_formatada = agendamento['data_agendamento'].strftime('%d-%m-%Y %H:%M')
        confirmacao = input(
            f"Confirma a exclusão do agendamento de {data_formatada} ({agendamento['motivo_servico']})? (S/N): "
        ).strip().upper()
        if confirmacao != 'S':
            print("\nExclusão cancelada.")
            return

        cursor.execute("DELETE FROM agendamento WHERE id_agendamento = %s", (id_agendamento,))
        conexao.commit()
        print("\n[SUCESSO] Agendamento excluído com sucesso!")
    except mysql.connector.Error as err:
        conexao.rollback()
        print(f"\n[ERRO] Falha ao excluir agendamento: {err}")
    finally:
        cursor.close()
        conexao.close()

def iniciar_modulo():
    """Menu principal do módulo de agendamentos."""
    while True:
        print("\n" + "="*45)
        print("   MÓDULO DE AGENDAMENTOS")
        print("="*45)
        print("1. Cadastrar Novo Agendamento")
        print("2. Listar Todos os Agendamentos")
        print("3. Atualizar Data do Agendamento")
        print("4. Excluir Agendamento")
        print("5. Voltar ao Painel Principal")
        
        opcao = input("\nEscolha uma opção: ").strip()
        
        if opcao == '1':
            cadastrar_agendamento()
        elif opcao == '2':
            listar_agendamentos()
        elif opcao == '3':
            atualizar_data_agendamento()
        elif opcao == '4':
            excluir_agendamento()
        elif opcao == '5':
            print("\nVoltando...")
            break
        else:
            print("\n[AVISO] Opção inválida!")

if __name__ == "__main__":
    iniciar_modulo()
